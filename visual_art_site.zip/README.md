# ศูนย์แหล่งเรียนรู้วิชาทัศนศิลป์

เว็บไซต์นี้สามารถโฮสต์บน GitHub Pages ได้โดยตรง

## วิธีใช้งาน

1. สร้าง repository ใหม่บน GitHub (เช่นชื่อ `visual-art-learning`)
2. อัปโหลดไฟล์ `index.html` ไปที่ root ของ repository
3. ไปที่ Settings > Pages เลือก branch `main` (หรือ `master`) และ root folder แล้วกด `Save`
4. รอระบบเผยแพร่ (ประมาณไม่กี่นาที) แล้วเข้าใช้งานผ่าน URL ที่ GitHub แจ้งไว้

## โครงสร้าง
- index.html : หน้าเว็บหลัก

## การแก้ไขเพิ่มเติม
ถ้าต้องการเพิ่มไฟล์ CSS/JS แยกออกมา ให้สร้างโฟลเดอร์เช่น `assets/` แล้วเชื่อมต่อจาก `index.html`

